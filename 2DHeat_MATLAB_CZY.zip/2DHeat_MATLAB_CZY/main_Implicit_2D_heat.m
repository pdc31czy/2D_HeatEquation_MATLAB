%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                      %
%    Example of Implicit Method for 2D heat equation                   %
%                                                                      %
%          u_t = u_{xx} + u_{yy} + f(x,t)                              %
%                                                                      %
%          u(0,x,y) = sin(2*pi*x) sin(2*pi*y)                          %
%          u(t,0,y) = 0                                                %
%          u(t,x,1) = 0                                                %
%          u_x(t,1,y) = 2*pi*exp(-t) sin(2*pi*y)                       %
%          u_y(t,x,0) = 2*pi*exp(-t) sin(2*pi*x)                       %
%                                                                      %
%    Test problme:                                                     %
%    Exact solution: u(t,x,y) = exp(-t) sin(2*pi*x) sin(2*pi*y)        %
%    Source term:  f(t,x,y) = 8*pi^2*exp(-t) sin(2*pi*x) sin(2*pi*y)   %
%                               -exp(-t) sin(2*pi*x) sin(2*pi*y)       %
%                                                                      %
%    Files needed for the test:                                        %
%                                                                      %
%     ADI_2D_heatequation.m:     This file, the main calling code.     %
%     f.m:         The file defines the f(t,x,y)                       %
%     uexact.m:    The exact solution.                                 %
%     ux.m:        The right boundary condition.                       %
%     uy.m:        The lower boundary condition.                       %
%                                                                      %
%     Results:         n              e            ratio               %
%                     10                                        
%     t_final=0.5     20           
%                     40                  
%                     80           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clearvars;
close all;
clc;

a = 0; b= 1; c = 0; d = 1; tfinal = 0.5; 

m=64; n=64;

hx = (b-a)/m; hx1 = hx*hx; x=zeros(m+1,1);
for i=1:m+1
  x(i) = a + (i-1)*hx;
end

hy = (d-c)/n; hy1 = hy*hy; y=zeros(n+1,1);
for i=1:n+1
  y(i) = c + (i-1)*hy;
end
dt = 0.1*hx*hy;

%-- Initial condition:
t = 0; 
for i = 1:m
    for j = 1:n
        U(i,j) = uexact(t,x(i+1),y(j));%U(i,j) = uexact(t,x(i+1),y(j+1));
    end
end
%---------- Big loop for time t ------------------------------------

k_t = fix(tfinal/dt);

for k1=1:k_t % k=1:k_t

t = t + dt; 

%—— ————— ——— ——— —— —— —— —— ——— ————— ——— ———— ——— ————
M = n*m; A = sparse(M,M); bf = zeros(M,1);
r = dt/hx1; %=dt/hy1

for j = 1:n
  for i=1:m
    k = i + (j-1)*m;
    bf(k) = U(i,j) + dt*f(t-dt, x(i+1),y(j)); %bf(k) = U(i,j) + dt*f(t-dt, x(i+1),y(j+1));
    A(k,k) = 1+4*r;
%-- x direction --------------
    if i == 1 %(2,j)
        A(k,k+1) = -r;
        bf(k) = bf(k);
    elseif i==m %(m+1,j)
         A(k,k-1) = -2*r;
         bf(k) = bf(k) + 2*r*hx*ux(t,x(i+1),y(j));%bf(k) = bf(k) + 2*r*hx*ux(t,x(i),y(j));
    else
	  A(k,k-1) = -r;
	  A(k,k+1) = -r;
    end

%-- y direction --------------

    if j == 1 %(i,1)
        A(k,k+m) = -2*r;
         bf(k) = bf(k) -2*r*hy*uy(t,x(i+1),y(j));
    elseif j==n %(i,n)
         A(k,k-m) = -r;
          bf(k) = bf(k) ;
    else
          A(k,k-m) = -r;
          A(k,k+m) = -r;
    end

  end
end

  ut = A \bf;
  U = reshape(ut,[m,n]);
%{
  for i = 1:m
      for j=1:n
          k = i + (j-1)*m;%  k = i + (j-1)*m; k = j + (i-1)*m;
          U(i,j) = ut(k);
      end
  end
%}
 %t = t + dt;

%--- finish implicit method at this time level, go to the next time level.
      
end       %-- Finished with the loop in time
  
%--- Transform back to (i,j) form to plot the solution ---

for i = 1:m
    for j = 1:n
        ue(i,j)=uexact(t,x(i+1),y(j));
    end
end


% Analyze abd Visualize the result.

e = max( max( abs(U-ue)))        % The maximum error,the infinity norm
err = norm(U-ue,2)*sqrt(hx*hy) %The truncation error,the 2 norm

%{
x1=x(2:m+1); y1=y(1:n);

mesh(y1,x1,ue);
title('The solution plot');
xlabel('y');
ylabel('x');
figure(2);
mesh(y1,x1,U-ue);
title('The error plot');
xlabel('y');
ylabel('x');
figure(3);
mesh(y1,x1,U);
title('The exact solution plot');
xlabel('y');
ylabel('x');
%}
        