function f = uy(t,x,y)

f = 2*pi*exp(-t)*sin(2*pi*x);

end