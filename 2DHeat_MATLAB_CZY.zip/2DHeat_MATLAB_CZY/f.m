function f = f(t,x,y)

f = 8*pi*pi*exp(-t)*sin(2*pi*x)*sin(2*pi*y) - exp(-t)*sin(2*pi*x)*sin(2*pi*y);

end