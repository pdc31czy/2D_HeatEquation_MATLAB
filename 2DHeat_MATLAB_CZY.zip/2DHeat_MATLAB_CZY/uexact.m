function f = uexact(t,x,y)

f = exp(-t)*sin(2*pi*x)*sin(2*pi*y);

end