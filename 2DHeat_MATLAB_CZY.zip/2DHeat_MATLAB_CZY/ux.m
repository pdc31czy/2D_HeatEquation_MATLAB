function f = ux(t,x,y)

f = 2*pi*exp(-t)*sin(2*pi*y);

end