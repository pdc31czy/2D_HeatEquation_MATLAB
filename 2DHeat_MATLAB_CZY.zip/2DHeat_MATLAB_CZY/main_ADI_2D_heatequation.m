%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                      %
%    Example of ADI Method for 2D heat equation                        %
%                                                                      %
%          u_t = u_{xx} + u_{yy} + f(x,t)                              %
%                                                                      %
%          u(0,x,y) = sin(2*pi*x) sin(2*pi*y)                          %
%          u(t,0,y) = 0                                                %
%          u(t,x,1) = 0                                                %
%          u_x(t,1,y) = 2*pi*exp(-t) sin(2*pi*y)                       %
%          u_y(t,x,0) = 2*pi*exp(-t) sin(2*pi*x)                       %
%                                                                      %
%    Test problme:                                                     %
%    Exact solution: u(t,x,y) = exp(-t) sin(2*pi*x) sin(2*pi*y)        %
%    Source term:  f(t,x,y) = 8*pi^2*exp(-t) sin(2*pi*x) sin(2*pi*y)   %
%                               -exp(-t) sin(2*pi*x) sin(2*pi*y)       %
%                                                                      %
%    Files needed for the test:                                        %
%                                                                      %
%     ADI_2D_heatequation.m:     This file, the main calling code.     %
%     f.m:         The file defines the f(t,x,y)                       %
%     uexact.m:    The exact solution.                                 %
%     ux.m:        The right boundary condition.                       %
%     uy.m:        The lower boundary condition.                       %
%                                                                      %
%     Results:         n              e            ratio               %
%                     10                                        
%     t_final=0.5     20           
%                     40                  
%                     80           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clearvars;
close all;
clc;

a = 0; b= 1; c=0; d=1; tfinal = 0.5;

m=64; %the number of mesh grids of x-direction
n=64; %the number of mesh grids of y-direction


hx = (b-a)/m; hx1 = hx*hx;
hy = (d-c)/n; hy1 = hy*hy;
dt = 0.1*hx*hy;
mu = dt/(2*hx1);

x = a:hx:b;
y = a:hy:b;

%-- Initial condition:
t = 0; 
for i = 1:m+1
    for j = 1:n+1
        u1(i,j) = uexact(t,x(i),y(j));
    end
end

%---------- Big loop for time t ------------------------------------

k_t = fix(tfinal/dt);

for tloop=1:k_t

t1 = t + dt; %u^{k}
t2 = t + dt/2; %u^{k+1/2}

%-------------- loop in the x direction-------------------

% ---- Dirichlet boundary condition for j = n+1
for i = 1:m+1      % The upper boundary condition u(t,x,1) = 0
    u2(i,n+1) = 0;
end

for j = 1:n+1    % The left boundary condition u(t,0,y) = 0
    u2(1,j) = 0;
end

% ---- Loop for fixed y(j) 
for j = 1:n     
    A = sparse(m,m); b=zeros(m,1);
    if j == 1 %j = 1 (x-direction)---ghost
        for i=2:m+1
            b(i-1) = u1(i,j) + (dt/2)*f(t2,x(i),y(j)) +...
                     mu*(-2*u1(i,j) + 2*u1(i,j+1)) - ...
		            (2*mu*hy*uy(t2,x(i),y(1))); %b()-after ghost
            if i == 2 %fixed j = 1, i = 2
                b(i-1) = b(i-1) + mu*uexact(t2,x(1),y(j)); %b()+mu*u(t,0,y)
                A(i-1,i) = -mu; %-mu
            elseif i==m+1 %fixed j = 1, i = m+1 ---ghost
                   b(i-1) = b(i-1) + (2*hx*mu*ux(t2,x(m+1),y(j))); %b()+2*hx*mu*u_x(t,1,y)
                   A(i-1,i-2) =  -2*mu; %-2*mu
            else %fixed 1< j <n+1, 2< i <m+1
	               A(i-1,i) = -mu; %-mu
	               A(i-1,i-2) = -mu; %-mu       
            end
            A(i-1,i-1) = 1+2*mu; %1+2*mu
        end
    
        ut = A\b;      % j = 1
        for i=1:m 
            u2(i+1,j) = ut(i); 
        end

    else % 1< j <n+1 (x-direction) or j = 2,...,n 即不是j=1和不是迪利克雷边界的剩下的
        for i=2:m+1
            b(i-1) = u1(i,j)+(dt/2)*f(t2,x(i),y(j))+...
                    mu*(u1(i,j-1) -2*u1(i,j) + u1(i,j+1)); %b()
            if i == 2 %fixed 1< j <n+1, i = 2
                b(i-1) = b(i-1) + mu*uexact(t2,x(1),y(j)); %b()+mu*u(t,0,y)
                A(i-1,i) = -mu; %-mu
            elseif i==m+1 %fixed 1< j <n+1,i = m+1
                   b(i-1) = b(i-1) + (2*hx*mu*ux(t2,x(m+1),y(j))); %b()+2*hx*mu*u_x(t,1,y)
                   A(i-1,i-2) =  -2*mu; %-2*mu
            else %fixed 1< j <n+1, 2< i <m+1
	               A(i-1,i) = -mu; %-mu
	               A(i-1,i-2) = -mu; %-mu    
            end
            A(i-1,i-1) = 1+2*mu; %1+2*mu
        end
  
        ut = A\b;      % j = 2, ..., n.
        for i=1:m
            u2(i+1,j) = ut(i);
        end
    end
 end     % Finish x-sweep.

%-------------- loop in y -direction --------------------------------

for i = 1:m+1      % The upper boundary condition u(t,x,1) = 0
    u1(i,n+1) = 0;
end

for j = 1:n+1    % The left boundary condition u(t,0,y) = 0
    u1(1,j) = 0;
end

for i = 2:m+1 % Loop for fixed x(i) 
    A = sparse(n,n); b=zeros(n,1);
    if i == m+1 %i = m+1 (y-direction)
        for j=1:n 
            b(j) = u2(i,j) + (dt/2)*f(t2,x(i),y(j)) +...
                    mu*(2*u2(i-1,j) -2*u2(i,j)) + ...
                    + (2*mu*hx*ux(t1,x(m+1),y(j))); %b() %%%%%%%%%
            if j == 1 %fixed i = m+1, j = 1
               b(j) = b(j) - (2*hy*mu*uy(t1,x(i),y(1))); %b()- 2*hy*mu*u_y(t,x,0)
               A(j,j+1) = -2*mu; %-2*mu
            elseif j==n %fixed i = m+1, j = n
                  b(j) = b(j) + mu*uexact(t1,x(i),y(n+1)); %b()+ mu*u(t,x,1)
                  A(j,j-1) =  -mu; %-mu
            else %fixed i = m+1, 1< j < n
                  A(j,j+1) = -mu; %-mu
                  A(j,j-1) = -mu; %-mu
            end
    
         A(j,j) = 1+2*mu;  %1+2*mu
         end
    
         ut = A\b;  % i = m+1
         for j=1:n
            u1(i,j) = ut(j);
         end
    
    else %1 < i < m+1  (y-direction) i = 2,...,m
         for j=1:n 
            b(j) = u2(i,j) + (dt/2)*f(t2,x(i),y(j)) + ...
                    mu*(u2(i-1,j) -2*u2(i,j)+ u2(i+1,j)); %b()
            if j == 1 %fixed 1 < i < m+1, j = 1
               b(j) = b(j) - (2*hy*mu*uy(t1,x(i),y(1))); %b()- 2*hy*mu*u_y(t,x,0)
               A(j,j+1) = -2*mu; %-2*mu
            elseif j==n %fixed 1 < i < m+1, j = n
                  b(j) = b(j) + mu*uexact(t1,x(i),y(n+1)); %b()+ mu*u(t,x,1)
                  A(j,j-1) =  -mu; %-mu
            else %fixed 1 < i < m+1, 1< j < n
                  A(j,j+1) = -mu; %-mu
                  A(j,j-1) = -mu; %-mu
            end
    
         A(j,j) = 1+2*mu;  %1+2*mu
         end
    
         ut = A\b;  % i = 2,...,m
         for j=1:n
            u1(i,j) = ut(j);
         end
    end
 end     % Finish y-sweep.

 t = t + dt;%!!!!整个code就是因为这里注释掉导致t一直没更新，
 % 以致于后面error一直没变，因为一直用的就是第一个dt的u和tfinal的u作比较

%--- finish ADI method at this time level, go to the next time level.
      
end       %-- Finished with the loop in time

%----------- Data analysis ----------------------------------

  for i=1:m+1
    for j=1:n+1
       ue(i,j) = uexact(tfinal,x(i),y(j));
    end
  end

  e = max(max(abs(u1-ue)))        % The infinity error.
  err = norm(u1-ue,2)*sqrt(hx*hy) %The truncation error,the 2 norm

  mesh(y,x,u1);title('Solution');  % Plot the computed solution
  xlabel('y');
  ylabel('x');
  figure(2);mesh(y,x,ue);title('Exact Solution');%Plot the exact solution
  xlabel('y');
  ylabel('x');
  figure(3); mesh(y,x,u1-ue);title('Error');  % Mesh plot of the error 
  xlabel('y');
  ylabel('x');
